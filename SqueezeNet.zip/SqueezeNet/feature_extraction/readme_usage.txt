
To call from matlab:
feature_extractor(path_of_txt_with_images,name_of_folder_to_store_feature_vectors)

Example:
path_of_txt_with_images='./input_images.txt' (if it is in the same folder than this function)
path_of_txt_with_images='C:/input_images.txt' (absolute path)

name_of_folder_to_store_feature_vectors='./output_vectors' (if it is in the same folder than this function)
name_of_folder_to_store_feature_vectors='C:/output_vectors' (absolute path)

If the output folder does not exist, it will be created

Note the need to put the text between ''


Example with the txt and images provided as example:
feature_extractor('./input_images.txt','output_vectors')