

function feature_extractor(input_txt,output_folder)

%create output folder if it does not exist
if ~exist(output_folder,"dir")
    mkdir(output_folder)
end

%load feature extraction network
load net_trained_LAST_feature_extractor.mat %lgraph_1
net=assembleNetwork(lgraph_1);
clear lgraph_1

%load txt file with input images

fileID = fopen(input_txt);
C = textscan(fileID,'%s');
fclose(fileID);
C=C{1};

for im=1:size(C,1)

    %extract image name without extension
    imagename_full=C{im};

    %find '/' separating folders
    k = strfind(imagename_full,'/');
    %
    if isempty(k) %no folders (assume that the text is the full image name)
        imagename=imagename_full;
    else
        imagename=imagename_full(k(end)+1:end);
    end
    %
    %might be '\' as well
    k = strfind(imagename,'\');
    %
    if isempty(k) %no folders (assume that the text is the full image name) - if the previous '/' was the case, then this option theoretically does nothing
        imagename=imagename;
    else
        imagename=imagename(k(end)+1:end);
    end

    %find '.' dot separing extension
    k = strfind(imagename,'.');
    %
    if isempty(k) %no dot (assume that the text is the full image name)
        imagename=imagename;
    else
        imagename=imagename(1:k(end)-1);
    end

    %read image
    imagen=imread(imagename_full);

    %check that it is rgb
    [I,J,K]=size(imagen);
    if K==1
        imagen(:,:,2)=imagen;
        imagen(:,:,3)=imagen(:,:,2);
    end
    if K~=3
        error('image does not have 3 channels')
    end

    %Resize shortest side to 129
    scale=129/min([size(imagen,1) size(imagen,2)]);
    imagen = imresize(imagen,scale);

    %Take 113x113 crop
    r = centerCropWindow2d(size(imagen),[113 113]);
    imagen = imcrop(imagen,r);

    %extract feature vector    
    feature_vector=activations(net,imagen,net.Layers(end-1).Name);
    feature_vector=squeeze(feature_vector);

    %extract flipped feature vector
    feature_vectorF=activations(net,fliplr(imagen),net.Layers(end-1).Name);
    feature_vectorF=squeeze(feature_vectorF);

    %average
    feature_vector=0.5*(feature_vector+feature_vectorF);

    %save in the output folder

    %mat format
    save([output_folder '/' imagename '.mat'],'feature_vector')

    %txt format    
    %fileID = fopen([output_folder '/' imagename '.txt'],'w');
    %fprintf(fileID,'%.100f\n',feature_vector)
    %fclose(fileID);




end


return


